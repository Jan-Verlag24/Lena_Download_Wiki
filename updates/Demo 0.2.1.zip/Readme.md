Der komplette Inhalt gehört Jan Löwen und darf nicht ohne Genehmigung veröffentlicht werden. Das verwendete Template liegt unter den Rechten von [nomnomnami.com](https://nomnomnami.com/index.html). Mehr dazu in [Credits.txt](credits.txt).



Für die neuen Bilder wurde die Anwendung GIMP verwendet.



Es wurde keine KI während der Erstellung verwendet.

